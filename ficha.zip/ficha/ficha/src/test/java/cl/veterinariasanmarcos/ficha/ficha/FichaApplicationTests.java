package cl.veterinariasanmarcos.ficha.ficha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FichaApplicationTests {

	@Test
	void contextLoads() {
	}

}
